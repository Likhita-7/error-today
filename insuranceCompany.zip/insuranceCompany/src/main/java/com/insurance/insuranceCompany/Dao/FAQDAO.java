package com.insurance.insuranceCompany.Dao;

import java.util.List;

import com.insurance.insuranceCompany.model.FAQ;

public interface FAQDAO {
	List<FAQ> getAllFAQS();
}
