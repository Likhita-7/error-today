package com.insurance.insuranceCompany.security;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.Dao.DaoLayer;
import com.insurance.insuranceCompany.model.LoginClass;

@Service
public class UserCredentialService implements UserDetailsService {

	@Autowired
	private DaoLayer daoLayer;
	@Autowired
	HttpSession session;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		LoginClass lc = daoLayer.getUserByUsername(username);
		System.out.println(lc);
		if (lc == null) {
			throw new UsernameNotFoundException("User not found");
		}
		session.setAttribute("login", lc.getRoleid());
		// Replace with actual roles from your database
		return User.builder().username(username).password(lc.getPassword()).roles(lc.getRoleid() + "").build();
	}
}
