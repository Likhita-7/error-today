package com.insurance.insuranceCompany.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.insuranceCompany.model.FAQ;
import com.insurance.insuranceCompany.repository.FAQRepository;


@RestController
public class FAQController {

	@Autowired(required=true)
	FAQRepository irrp;
	
	@GetMapping(value = "/getFAQS")
    public List<FAQ> getAllFAQS(Model model) {
        System.out.println("varshu2");
        List<FAQ> li = irrp.getAllFAQS();
        model.addAttribute("list", li);
        System.out.println(li);
        return li;
    }
}